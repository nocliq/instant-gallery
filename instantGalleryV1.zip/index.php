<!DOCTYPE HTML>
<html>       
  <head>         
    <meta charset="utf-8">         
    <meta name="viewport" content="width=device-width; initial-scale=1.0; minimum-scale=1.0; maximum-scale=1.0; user-scalable=0;"/>         
    <meta name="apple-touch-fullscreen" content="yes" />                
	<title>Portfolio :: Galeria</title>
	   
    <!--
            
            <base href="http://galeria.atlier.net/" />
            
            -->      
    <!-- this is the javascript allowing html5 to run in older browsers -->   
    <script src="js/modernizr-1.7.min.js"></script>     
            
    <link rel="stylesheet" type="text/css" href="css/sen.css" media="screen" />         
    
           <link rel="stylesheet" type="text/css" href="css/style.css" />
	<link rel="stylesheet" type="text/css" href="css/fancy.css" />
	
     
    <link rel="stylesheet" type="text/css" href="css/mobile.css" media="handheld" />    
    <!--[if IE 6]>
        <link href="http://universal-ie6-css.googlecode.com/files/ie6.0.3.css" rel="stylesheet" type="text/css" media="screen" >
        <![endif]-->           
    <!--[if IE]> <style> .report_bugs {left:0px;} </style>	<![endif]-->     
           
<!--<script src="http://cdn.jquerytools.org/1.2.5/jquery.tools.min.js"></script>-->
    
	<script type="text/javascript" src="js/jquery-1.2.3.pack.js"></script>
	<!--<script type="text/javascript" src="js/tinybox.pack.js"></script>-->
	<script type="text/javascript" src="js/jquery.fancybox-1.0.0.js"></script>

	        
<script type="text/javascript">


        $(function() {
      	// initialize gallery
      	//$(".photo-link").TINY.box.show({image:'images/rhino.jpg',boxid:'frameless',animate:true,openjs:function(){openJS()}})
      	$(".photo-link").fancybox({ 'zoomSpeedIn': 300, 'zoomSpeedOut': 200, 'overlayShow': true });
      }); 		

      $(document).ready(function() {
      
         
        	// select #flowplanes and make it scrollable. use circular and navigator plugins
        	$("#flowpanes").scrollable({ circular: true}).navigator({
        		// select #flowtabs to be used as navigator
        		navi: "#flowtabs",
        		// select A tags inside the navigator to work as items (not direct children)
        		naviItem: 'a',
        		// assign "current" class name for the active A tag inside navigator
        		activeClass: 'current',
        		// make browser's back button work
        		history: true
        	});
        	
        	 
      });  
     
		
		    // perform JavaScript after the document is scriptable.
      $(function() {
      	// setup ul.tabs to work as tabs for each div directly under div.panes
      	$("ul.tabs").tabs("div.panes > div", {effect: 'ajax', history: true});
      });
      // execute your scripts when the DOM is ready. this is mostly a good habit
      $(function() {
      	// initialize scrollable
      	$(".scrollable").scrollable({circular: true, mousewheel: true});
      }); 
      
      // make #myelement listen for mousewheel events
          $(".scrollable").mousewheel(function(event, delta) {
      });
      
      
      
		
    </script> 
            
  </head>  
	

<body>

	<div id="page-wrap">
		<span id="report_bugs"><a href="">FEED ME </a>SOME IMGS!</span>
<header>	
	<nav id="tabs">                               
          <!-- the tabs -->                       
          <ul> 

        <?php 
$catg = (!isset($catg)) ? $catg = filter_var($_REQUEST['catg'], FILTER_SANITIZE_STRING) : $catg = 'imgs';

$cachedir = 'cache';
$dir = 'portfolio/'.$catg;
$per_column = 6;
$files 		= glob($dir . '/*.{JPG,jpeg,jpg,gif,png,.swf,.avi,.mpg}', GLOB_BRACE);

/*ROUND SIZE NUMBERS*/
function format_size($size) {
      $sizes = array(" Bytes", " KB", " MB", " GB", " TB", " PB", " EB", " ZB", " YB");
      if ($size == 0) { return('n/a'); } else {
      return (round($size/pow(1024, ($i = floor(log($size, 1024)))), $i > 1 ? 2 : 0) . $sizes[$i]); }
}
/*generate menu items from dirs */
			 $dportfolio = 'portfolio/';
			 
					function dir_list($d) {
					foreach(array_diff(scandir($d),array('.','..')) as $f)
						if(is_dir($d . '/' . $f))
							$l[] = $f;
					return $l;
				}
			
				$d = dir_list($dportfolio);
				if($d){
					
					foreach($d as $f){ ?>
					  <li class="button"> 
						<a class="<?php echo(($catg == $f) ? 'active': ''); ?>" href="index.php?catg=<?php echo $f; ?>">
						  <?php echo $f; ?></a> 
					  </li> 
					  
					  <?php }
					  
					  }
					  ?>            
            
          </ul> 
    </nav>             
	
	</header>
<section class="panes">
	
	<?php

		
				
 define( 'THUMBNAIL_IMAGE_MAX_WIDTH', 80 );
 define( 'THUMBNAIL_IMAGE_MAX_HEIGHT', 52 );

function generate_image_thumbnail($source_image_path, $thumbnail_image_path) {
		list($source_image_width, $source_image_height, $source_image_type) = getimagesize($source_image_path);

		switch ( $source_image_type ) {
			case IMAGETYPE_GIF :
				$source_gd_image = imagecreatefromgif($source_image_path);
				break;

			case IMAGETYPE_JPEG :
				$source_gd_image = imagecreatefromjpeg($source_image_path);
				break;

			case IMAGETYPE_PNG :
				$source_gd_image = imagecreatefrompng($source_image_path);
				break;
		}

		if($source_gd_image === false) {
			return false;
		}

		$thumbnail_image_width = THUMBNAIL_IMAGE_MAX_WIDTH;
		$thumbnail_image_height = THUMBNAIL_IMAGE_MAX_HEIGHT;

		$source_aspect_ratio = $source_image_width / $source_image_height;
		$thumbnail_aspect_ratio = $thumbnail_image_width / $thumbnail_image_height;

		if($source_image_width <= $thumbnail_image_width && $source_image_height <= $thumbnail_image_height) {
			$thumbnail_image_width = $source_image_width;
			$thumbnail_image_height = $source_image_height;
		} elseif($thumbnail_aspect_ratio > $source_aspect_ratio) {
			$thumbnail_image_width = ( int )($thumbnail_image_height * $source_aspect_ratio);
		} else {
			$thumbnail_image_height = ( int )($thumbnail_image_width / $source_aspect_ratio);
		}

		$thumbnail_gd_image = imagecreatetruecolor($thumbnail_image_width, $thumbnail_image_height);

		imagecopyresampled($thumbnail_gd_image, $source_gd_image, 0, 0, 0, 0, $thumbnail_image_width, $thumbnail_image_height, $source_image_width, $source_image_height);

		imagejpeg($thumbnail_gd_image, $thumbnail_image_path, 90);

		imagedestroy($source_gd_image);

		imagedestroy($thumbnail_gd_image);

		return true;
	}




$out = " <h3>" . $catg ."</3>";
            	
    
    if ($handle = @opendir($dir)or die("<h5>Projecto n�o tem imagens</h5>$out")) {
    $count=0;
    $out .= "<ul class='polaroids'>";
 
    while (false !== ($file = readdir($handle))) {
      //clears last results from cache
      clearstatcache(); 
      
	if(is_file($dir.'/'.$file)){
		/*Check Cache for img */
		if(!file_exists($cachedir.'/tb-'.$file)){
			generate_image_thumbnail($dir.'/'.$file, $cachedir.'/tb-'.$file);
			
		}
      	$count++;
//$out .= " <li class='nosel'><a rel='lightbox-cat' title='".$file."' href='".$dir.'/'.$file."'><img src='".$cachedir.'/'.$file."?".$time."' width='80' heigth='52' title='aumentar' /></a>";
//  $out .= " <li class='nosel'><a rel='lightbox-cat' title='".$file."' href='".$dir.'/'.$file."'><img src='".$dir.'/'.$file."?".$time."' width='80' heigth='52' title='aumentar' /></a>";
      $trimmed = rtrim($file, "\.jpg\.png\.gif");
	  $ext = ltrim($file, "\.");
	  $fsize = format_size(filesize($dir.'/'.$file)); 
		$out .= "<li><a class='photo-link' rel='one-big-group' title='".$trimmed."' href='".$dir.'/'.$file."'><img src='".$cachedir.'/tb-'.$file."' width='80' heigth='52' title='aumentar' /><span id='caption'><h3>".$fsize."</h3><p>".$ext."</p></span></a></li>";
				if($count % $per_column == 0) {
					 $out .= "<div class='clearfix'></div>"; 
					 }
        
        }
		 
    }
   closedir($handle);

   echo $out; 
}
		
	?>
	
</section>
	
	                                     
	</div>

</body>

</html>