 <?php 
   
   $catg = isset($_GET['catg']) ? $_GET['catg'] : 'default'; 
   
   require('class/Thumbs.php');
   include('class/Upload.php');
   
 define( 'THUMBNAIL_IMAGE_MAX_WIDTH', 80 );
 define( 'THUMBNAIL_IMAGE_MAX_HEIGHT', 52 );
 define( 'PORTFOLIO_DIR', 'portfolio/' );
   
   ?>
   
   
  <?php 

              
    
if(isset($_FILES)&& !empty($_FILES)){

  $up = new fileDir($_SERVER["DOCUMENT_ROOT"].PORTFOLIO_DIR.'up/'.$catg.'/');
	
	//$up->arrExtPermits('JPG','jpeg','jpg','gif','png','swf','avi','mpg');
  $up->upload($_FILES['file']);
 
  echo '<p>'.$up->location().'</p>';
  // outputs: yourServersAbsolutePath/myUploads/
  echo '<p>'.$up->fileName().'</p>';
  // outputs: myPic.jpg if our last uploaded file was named myPic.jpg.
} else {
?>
<!DOCTYPE HTML>
<html>       
  <head>         
      <!-- Always force latest IE rendering engine (even in intranet) & Chrome Frame 
       Remove this if you use the .htaccess -->
  <meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1">
      <meta charset="utf-8">         
    <meta name="viewport" content="width=device-width; initial-scale=1.0; minimum-scale=1.0; maximum-scale=1.0; user-scalable=0;"/>         
    <meta name="apple-touch-fullscreen" content="yes" />
      <meta name="description" content="">
  <meta name="author" content="www.arakno.net">                
	<title>Portfolio :: Instant-Gallery</title>

    <!-- this is the javascript allowing html5 to run in older browsers -->   
    <script src="js/modernizr2-custom.js"></script>     
            
    <link rel="stylesheet" type="text/css" href="css/sen.css" media="screen" />         
    <link rel="stylesheet" type="text/css" href="css/style.css" />
    <link rel="stylesheet" type="text/css" href="css/mobile.css" media="handheld" /> 
    
<link rel="stylesheet" href="css/jquery.fileupload-ui.css">    
       
    <!--[if IE 6]>
        <link href="http://universal-ie6-css.googlecode.com/files/ie6.0.3.css" rel="stylesheet" type="text/css" media="screen" >
        <![endif]-->           
    <!--[if IE]> <style> .uploadme {left:0px;} </style>	<![endif]-->     
           
     <!-- Grab Google CDN's jQuery. fall back to local if necessary -->
<script src="http://ajax.googleapis.com/ajax/libs/jquery/1.5.1/jquery.min.js"></script>
<script>!window.jQuery && document.write('<script src="js/jquery-1.5.2.min.js"><\/script>')</script>

<script src="http://ajax.googleapis.com/ajax/libs/jqueryui/1.8.10/jquery-ui.min.js"></script>
<script src="js/tinybox.pack.js"></script>


</head>
<body>

	<div id="page-wrap">
 <header>	  
	<nav id="tabs">                               
    <ul> 
         
        <?php 
           echo $_SERVER["DOCUMENT_ROOT"].PORTFOLIO_DIR.'up/'.$catg.'/';
       //echo $_SERVER["DOCUMENT_ROOT"].'portfolio/'.PORTFOLIO_DIR.$catg.'/';
       
$cachedir = 'cache';
$dir = PORTFOLIO_DIR.$catg;
$per_column = 6;
$files 		= glob($dir . '/*.{JPG,jpeg,jpg,gif,png,swf,avi,mpg}', GLOB_BRACE);

/*ROUND SIZE NUMBERS*/
function format_size($size) {
      $sizes = array(" Bytes", " KB", " MB", " GB", " TB", " PB", " EB", " ZB", " YB");
      if ($size == 0) { return('n/a'); } else {
      return (round($size/pow(1024, ($i = floor(log($size, 1024)))), $i > 1 ? 2 : 0) . $sizes[$i]); }
}
/*generate menu items from dirs */			 
					function dir_list($d) {
					foreach(array_diff(scandir($d),array('.','..')) as $f)
						if(is_dir($d . '/' . $f))
							$l[] = $f;
					return $l;
				}
			
				$d = dir_list(PORTFOLIO_DIR);
				if($d){
					
					foreach($d as $f){ ?>
					  <li class="button"> 
						<a class="<?php echo(($catg == $f) ? 'active': ''); ?>" href="index.php?catg=<?php echo $f; ?>">
						  <?php echo $f; ?></a> 
					  </li> 
					  
					  <?php }
					  
					  }
					  ?>            
            
      </ul> 
    </nav>
            
	
	</header> 
<section class="panes">

	
	<?php



$out = " <h4>" . $catg ."</h4>";
            	
    
    if ($handle = @opendir($dir)or die("<h4>No images in this category</h4>$out")) {
    $count=0;
    $out .= "<ul class='polaroids'>";
 
    while (false !== ($file = readdir($handle))) {
      //clears last results from cache
      clearstatcache(); 
      
	if(is_file($dir.'/'.$file)){
		/*Check Cache for img */
		if(!file_exists($cachedir.'/tb-'.$file)){	
	 //Instantiate Class
	    $thumb = new Thumbs;
			$thumb->source_image_path =  $dir.'/'.$file;
			$thumb->thumbnail_image_path =  $cachedir.'/tb-'.$file;
			$thumb->generate_thumbs();
		}
    $count++;
        
    $trimmed = rtrim($file, "\.jpg\.png\.gif\.jpeg");
	  $ext = ltrim($file, "\.");
	  $fsize = format_size(filesize($dir.'/'.$file)); 
		$out .= "<li><a class='photo-link' title='click to Enlarge' href='".$dir.'/'.$file."'><img src='".$cachedir.'/tb-'.$file."' width='80' heigth='52' title='".$trimmed."' /><span id='caption'><h3>".$fsize."</h3><p>".$ext."</p></span></a></li>";
				if($count % $per_column == 0) {
					 $out .= "<div class='clearfix'></div>"; 
					 }
        
        }
		 
    }
   closedir($handle);

   echo $out; 
}
		
	?>
	
</section>	
	

<div id="label">
<form id="file_upload" action="<?php echo $_SERVER["REQUEST_URI"]; ?>" method="POST" enctype="multipart/form-data">
    <input type="file" name="file" multiple>
    <button>Upload</button>
    <div>Upload files</div>
</form>
<table id="files"></table>
<script src="js/jquery.fileupload.js"></script>
<script src="js/jquery.fileupload-ui.js"></script>


 
    <span id="uploadme">
<a href="">FEED ME IMGS!</a></span>
 

  </div>

</div>  
<footer>
</footer>

 
</body> 
</html> 
<script>
/*global $ */
   //if ESC is pressed
$(document).keyup(function(e) {
  if(e.keyCode == 27) {
    $('#label').animate({
      "width": "100px"}, 1000, "easeOutBounce");
  }
});

$(function () {
   	 $(".photo-link").click(function(e){
     e.preventDefault();
    var clicked = $(this).attr('href');
  TINY.box.show({image:clicked,boxid:'success',animate:true,opacity:80});
  
  }); 
 
    
     $("#label").click(function(e){
     e.preventDefault();
        $("#label").animate({width: "100%"}, {duration: 500, specialEasing: { left: 'easeOutBounce'}})
        })
        
        
  
$("#uploadme").html('<p>Choose image(s) to upload to category &ldquo;<?php echo $catg; ?>&rdquo;</p>'); 


    $('#file_upload').fileUploadUI({
        uploadTable: $('#files'),
        downloadTable: $('#files'),
        buildUploadRow: function (files, index) {
            return $('<tr><td>' + files[index].name + '<\/td>' +
                    '<td class="file_upload_progress"><div><\/div><\/td>' +
                    '<td class="file_upload_cancel">' +
                    '<button class="ui-state-default ui-corner-all" title="Cancel">' +
                    '<span class="ui-icon ui-icon-cancel">Cancel<\/span>' +
                    '<\/button><\/td><\/tr>');
        },
        buildDownloadRow: function (file) {
            return $('<tr><td>' + file.name + '<\/td><\/tr>');
        }
    });
});
</script> 

		
<?php		
}
?>   